<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Understanding Cookies - Comprehensive Guide</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #fff8f0;
            color: #5a3e36;
        }

        header {
            background-color: #d4a373;
            color: white;
            padding: 15px 0;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        nav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s ease;
            padding: 5px 10px;
            border-radius: 5px;
        }

        nav ul li a:hover {
            color: #f4e8c1;
            background-color: rgba(255, 255, 255, 0.1);
        }

        main {
            padding: 25px;
            max-width: 900px;
            margin: 20px auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 100px;
        }

        footer {
            background-color: #d4a373;
            color: white;
            text-align: center;
            padding: 15px 0;
            position: fixed;
            width: 100%;
            bottom: 0;
            box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.1);
        }

        h1, h2, h3 {
            color: #5a3e36;
        }

        h1 {
            font-size: 2.2em;
            border-bottom: 2px solid #d4a373;
            padding-bottom: 10px;
        }

        h2 {
            font-size: 1.8em;
            margin-top: 30px;
            border-bottom: 1px dashed #d4a373;
            padding-bottom: 5px;
        }

        h3 {
            font-size: 1.4em;
            color: #8b5a2b;
        }

        p {
            line-height: 1.6;
            margin-bottom: 15px;
        }

        ul, ol {
            padding-left: 25px;
        }

        ul li, ol li {
            margin-bottom: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        th, td {
            border: 1px solid #d4a373;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f4e8c1;
        }

        .card {
            background-color: #faf3e0;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .btn {
            display: inline-block;
            background-color: #d4a373;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #c08a5a;
        }

        .page {
            display: none;
        }

        .page.active {
            display: block;
        }

        .comparison-table {
            width: 100%;
            margin: 20px 0;
        }

        .comparison-table th {
            background-color: #d4a373;
            color: white;
        }

        .feature-box {
            background-color: #fff8f0;
            border-left: 4px solid #d4a373;
            padding: 15px;
            margin: 15px 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>Understanding Cookies</h1>
        <nav>
            <ul>
                <li><a href="#home" class="nav-link">Home</a></li>
                <li><a href="#types" class="nav-link">Types of Cookies</a></li>
                <li><a href="#management" class="nav-link">Managing Cookies</a></li>
                <li><a href="#security" class="nav-link">Cookie Security</a></li>
                <li><a href="#legislation" class="nav-link">Cookie Laws</a></li>
                <li><a href="#browsers" class="nav-link">Browser Guide</a></li>
                <li><a href="#faq" class="nav-link">FAQ</a></li>
                <li><a href="#references" class="nav-link">References</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- Home Page -->
        <section id="home" class="page active">
            <h2>Welcome to Our Comprehensive Guide on Web Cookies</h2>
            <p>This website provides detailed information about web cookies, their various types, management techniques, security considerations, and legal aspects. Whether you're a casual internet user or a web developer, you'll find valuable information here.</p>
            
            <div class="card">
                <h3>Quick Navigation</h3>
                <ul>
                    <li><a href="#types" class="btn">Learn about different cookie types</a></li>
                    <li><a href="#management" class="btn">Discover how to manage cookies</a></li>
                    <li><a href="#security" class="btn">Understand cookie security</a></li>
                    <li><a href="#legislation" class="btn">Explore cookie legislation</a></li>
                </ul>
            </div>
            
            <div class="feature-box">
                <h3>Did You Know?</h3>
                <p>The term "cookie" in web browsers comes from "magic cookie," a concept in Unix programming representing a small piece of data passed between programs.</p>
            </div>
        </section>

        <!-- Types of Cookies Page -->
        <section id="types" class="page">
            <h2>Types of Web Cookies</h2>
            <p>Cookies come in several varieties, each serving different purposes in web browsing and user experience.</p>
            
            <table class="comparison-table">
                <tr>
                    <th>Cookie Type</th>
                    <th>Duration</th>
                    <th>Purpose</th>
                    <th>Security</th>
                </tr>
                <tr>
                    <td><strong>Session Cookies</strong></td>
                    <td>Temporary</td>
                    <td>Maintain user session state</td>
                    <td>Generally safe</td>
                </tr>
                <tr>
                    <td><strong>Persistent Cookies</strong></td>
                    <td>Days to years</td>
                    <td>Remember preferences/logins</td>
                    <td>Secure if properly implemented</td>
                </tr>
                <tr>
                    <td><strong>Secure Cookies</strong></td>
                    <td>Varies</td>
                    <td>HTTPS-only secure data</td>
                    <td>Very secure</td>
                </tr>
                <tr>
                    <td><strong>Third-Party Cookies</strong></td>
                    <td>Varies</td>
                    <td>Tracking/advertising</td>
                    <td>Privacy concerns</td>
                </tr>
                <tr>
                    <td><strong>Supercookies</strong></td>
                    <td>Persistent</td>
                    <td>Advanced tracking</td>
                    <td>High privacy risk</td>
                </tr>
            </table>
            
            <div class="card">
                <h3>Technical Cookie Attributes</h3>
                <ul>
                    <li><strong>Domain:</strong> Specifies which domain can access the cookie</li>
                    <li><strong>Path:</strong> Limits cookie access to specific paths</li>
                    <li><strong>Expires/Max-Age:</strong> Controls cookie lifetime</li>
                    <li><strong>Secure:</strong> Only sent over HTTPS</li>
                    <li><strong>HttpOnly:</strong> Not accessible via JavaScript</li>
                    <li><strong>SameSite:</strong> Controls cross-site sending</li>
                </ul>
            </div>
        </section>

        <!-- Managing Cookies Page -->
        <section id="management" class="page">
            <h2>Managing Web Cookies</h2>
            <p>Effective cookie management helps balance convenience with privacy and security.</p>
            
            <div class="card">
                <h3>Browser-Specific Management</h3>
                <ul>
                    <li><strong>Chrome:</strong> Settings > Privacy and security > Cookies and other site data</li>
                    <li><strong>Firefox:</strong> Options > Privacy & Security > Cookies and Site Data</li>
                    <li><strong>Safari:</strong> Preferences > Privacy > Cookies and website data</li>
                    <li><strong>Edge:</strong> Settings > Cookies and site permissions</li>
                </ul>
            </div>
            
            <h3>Cookie Management Strategies</h3>
            <ol>
                <li>Regularly clear cookies (monthly recommended)</li>
                <li>Block third-party cookies for enhanced privacy</li>
                <li>Use private/incognito browsing for sensitive activities</li>
                <li>Whitelist trusted sites that require cookies</li>
                <li>Consider using cookie management extensions</li>
            </ol>
            
            <div class="feature-box">
                <h3>Cookie Auto-Delete Tools</h3>
                <p>Browser extensions like "Cookie AutoDelete" can automatically remove cookies from sites you're not actively using, providing both convenience and privacy.</p>
            </div>
        </section>

        <!-- Cookie Security Page -->
        <section id="security" class="page">
            <h2>Cookie Security Considerations</h2>
            <p>Understanding cookie security helps protect your online accounts and personal information.</p>
            
            <div class="card">
                <h3>Common Cookie Security Risks</h3>
                <ul>
                    <li><strong>Session Hijacking:</strong> Attackers steal session cookies to impersonate users</li>
                    <li><strong>Cross-Site Scripting (XSS):</strong> Malicious scripts steal cookies</li>
                    <li><strong>Cross-Site Request Forgery (CSRF):</strong> Unauthorized actions using user cookies</li>
                    <li><strong>Cookie Tossing:</strong> Submitting cookies from other domains</li>
                </ul>
            </div>
            
            <h3>Best Practices for Secure Cookies</h3>
            <table>
                <tr>
                    <th>Practice</th>
                    <th>Description</th>
                    <th>Benefit</th>
                </tr>
                <tr>
                    <td>Use Secure Flag</td>
                    <td>Only transmit cookies over HTTPS</td>
                    <td>Prevents man-in-the-middle attacks</td>
                </tr>
                <tr>
                    <td>Use HttpOnly Flag</td>
                    <td>Prevent JavaScript access</td>
                    <td>Mitigates XSS attacks</td>
                </tr>
                <tr>
                    <td>Implement SameSite</td>
                    <td>Control cross-site requests</td>
                    <td>Prevents CSRF attacks</td>
                </tr>
                <tr>
                    <td>Short Expiration</td>
                    <td>Limit cookie lifetime</td>
                    <td>Reduces attack window</td>
                </tr>
            </table>
        </section>

        <!-- Cookie Legislation Page -->
        <section id="legislation" class="page">
            <h2>Cookie Legislation Worldwide</h2>
            <p>Various laws regulate how websites can use cookies and track users.</p>
            
            <div class="card">
                <h3>Key Cookie-Related Regulations</h3>
                <ul>
                    <li><strong>GDPR (EU):</strong> Requires explicit consent for non-essential cookies</li>
                    <li><strong>ePrivacy Directive (EU):</strong> Specific rules for electronic communications</li>
                    <li><strong>CCPA (California):</strong> Gives users right to opt-out of data collection</li>
                    <li><strong>PECR (UK):</strong> UK implementation of ePrivacy rules</li>
                </ul>
            </div>
            
            <h3>Compliance Requirements</h3>
            <ol>
                <li>Obtain informed consent before setting cookies</li>
                <li>Provide clear information about cookie usage</li>
                <li>Allow users to easily withdraw consent</li>
                <li>Maintain records of consent</li>
                <li>Make essential site functionality available without tracking cookies</li>
            </ol>
            
            <div class="feature-box">
                <h3>Cookie Consent Banner Best Practices</h3>
                <p>Effective consent banners should be clear, specific, and provide equal ease for accepting or rejecting cookies. Dark patterns that nudge users toward acceptance are increasingly being penalized.</p>
            </div>
        </section>

        <!-- Browser Guide Page -->
        <section id="browsers" class="page">
            <h2>Browser-Specific Cookie Guides</h2>
            <p>Each browser handles cookies slightly differently. Here's how to manage them in popular browsers.</p>
            
            <div class="grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
                <div class="card">
                    <h3>Google Chrome</h3>
                    <ol>
                        <li>Click the three-dot menu > Settings</li>
                        <li>Select "Privacy and security"</li>
                        <li>Choose "Cookies and other site data"</li>
                        <li>Adjust settings as needed</li>
                    </ol>
                </div>
                
                <div class="card">
                    <h3>Mozilla Firefox</h3>
                    <ol>
                        <li>Click the hamburger menu > Options</li>
                        <li>Select "Privacy & Security"</li>
                        <li>Scroll to "Cookies and Site Data"</li>
                        <li>Configure your preferences</li>
                    </ol>
                </div>
                
                <div class="card">
                    <h3>Apple Safari</h3>
                    <ol>
                        <li>Open Safari > Preferences</li>
                        <li>Go to the "Privacy" tab</li>
                        <li>Manage "Cookies and website data"</li>
                        <li>Set your preferred level of blocking</li>
                    </ol>
                </div>
            </div>
            
            <h3>Emerging Browser Changes</h3>
            <p>Modern browsers are increasingly restricting third-party cookies by default:</p>
            <ul>
                <li>Firefox blocks third-party tracking cookies by default</li>
                <li>Safari implements Intelligent Tracking Prevention (ITP)</li>
                <li>Chrome is phasing out third-party cookies (planned for 2024)</li>
                <li>Edge follows Chrome's lead with tracking prevention</li>
            </ul>
        </section>

        <!-- FAQ Page -->
        <section id="faq" class="page">
            <h2>Frequently Asked Questions</h2>
            
            <div class="card">
                <h3>Are cookies dangerous?</h3>
                <p>Cookies themselves are not dangerous - they're just text files. However, they can be used for tracking, and stolen cookies can be used to hijack sessions. Proper cookie management minimizes risks.</p>
            </div>
            
            <div class="card">
                <h3>Should I accept all cookies?</h3>
                <p>It's generally better to be selective. Accept only necessary cookies (for site functionality) and evaluate whether to accept others based on your privacy preferences.</p>
            </div>
            
            <div class="card">
                <h3>What's the difference between first-party and third-party cookies?</h3>
                <p>First-party cookies are set by the site you're visiting, while third-party cookies are set by other domains (usually advertisers or analytics services).</p>
            </div>
            
            <div class="card">
                <h3>Do I need to accept cookies to use websites?</h3>
                <p>For most sites, you need to accept necessary cookies for basic functionality, but you can often reject non-essential cookies (like those for tracking or advertising).</p>
            </div>
            
            <div class="card">
                <h3>How often should I clear my cookies?</h3>
                <p>This depends on your privacy needs. Monthly is reasonable for most users, while privacy-conscious users might clear them weekly or after each browsing session.</p>
            </div>
        </section>

        <!-- References Page -->
        <section id="references" class="page">
            <h2>References and Resources</h2>
            
            <div class="card">
                <h3>Official Documentation</h3>
                <ul>
                    <li><a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Cookies" target="_blank">MDN Web Docs: HTTP Cookies</a></li>
                    <li><a href="https://tools.ietf.org/html/rfc6265" target="_blank">RFC 6265: HTTP State Management Mechanism</a></li>
                    <li><a href="https://gdpr-info.eu/" target="_blank">General Data Protection Regulation (GDPR)</a></li>
                    <li><a href="https://oag.ca.gov/privacy/ccpa" target="_blank">California Consumer Privacy Act (CCPA)</a></li>
                </ul>
            </div>
            
            <div class="card">
                <h3>Additional Learning Resources</h3>
                <ul>
                    <li><a href="https://www.cookiepro.com/knowledge/" target="_blank">CookiePro Knowledge Center</a></li>
                    <li><a href="https://www.allaboutcookies.org/" target="_blank">All About Cookies</a></li>
                    <li><a href="https://web.dev/articles/samesite-cookies-explained" target="_blank">SameSite Cookies Explained</a></li>
                    <li><a href="https://cookiepedia.co.uk/" target="_blank">Cookiepedia</a></li>
                </ul>
            </div>
            
            <div class="card">
                <h3>Cookie Management Tools</h3>
                <ul>
                    <li><a href="https://chrome.google.com/webstore/detail/cookie-autodelete/fhcgjolkccmbidfldomjliifgaodjagh" target="_blank">Cookie AutoDelete (Chrome)</a></li>
                    <li><a href="https://addons.mozilla.org/en-US/firefox/addon/cookie-autodelete/" target="_blank">Cookie AutoDelete (Firefox)</a></li>
                    <li><a href="https://www.ghostery.com/" target="_blank">Ghostery Privacy Suite</a></li>
                    <li><a href="https://privacybadger.org/" target="_blank">Privacy Badger</a></li>
                </ul>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2023 Understanding Cookies | Last Updated: October 2023</p>
        <p>This site uses only necessary cookies for basic functionality.</p>
    </footer>

    <script>
        // Page navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Hide all pages
                document.querySelectorAll('.page').forEach(page => {
                    page.classList.remove('active');
                });
                
                // Show selected page
                const pageId = this.getAttribute('href').substring(1);
                document.getElementById(pageId).classList.add('active');
                
                // Update URL
                history.pushState(null, null, `#${pageId}`);
            });
        });
        
        // Show home page by default if no hash
        window.addEventListener('load', function() {
            if (!window.location.hash) {
                document.getElementById('home').classList.add('active');
            } else {
                const pageId = window.location.hash.substring(1);
                if (document.getElementById(pageId)) {
                    document.getElementById(pageId).classList.add('active');
                }
            }
        });
        
        // Handle back/forward navigation
        window.addEventListener('popstate', function() {
            const pageId = window.location.hash.substring(1);
            document.querySelectorAll('.page').forEach(page => {
                page.classList.remove('active');
            });
            if (pageId && document.getElementById(pageId)) {
                document.getElementById(pageId).classList.add('active');
            } else {
                document.getElementById('home').classList.add('active');
            }
        });
    </script>
</body>
</html>